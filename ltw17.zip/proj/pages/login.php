<?php
    include_once('../templates/header.php');
    include_once('../templates/login_form.php');
    include_once('../templates/footer.php');
?>
