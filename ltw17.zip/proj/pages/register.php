<?php
    include_once('../config/init.php');
    include_once('../templates/header.php');
    include_once('../templates/signup_form.php');
    include_once('../templates/footer.php');
?>
