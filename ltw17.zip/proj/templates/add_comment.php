<section id="content">
  <h2>Add Comment</h2>
  <form action="../actions/action_add_comment.php" method="post">
    <label>Comment:
      <input type="text" name="comment">
    </label>
    <input type="submit">
  </form>
</section>
