<footer>
    <p>&copy; 2018 All rights reserved</p>
</footer>


</body>
</html>